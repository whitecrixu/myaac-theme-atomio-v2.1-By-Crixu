<?php
defined('MYAAC') or die('Direct access not allowed!');
?>
<div class="well">
	<div class="header">
		Follow Us
	</div>
	<div class="body">
		<table class="smedia centralizeContent table-100">
			<tr>
				<td><a href="<?=config('follow_facebook')?>" target="_blank"><i class="fa fa-facebook"></i> </a></td>
				<td><a href="<?=config('follow_twitter')?>" target="_blank"><i class="fa fa-twitter"></i> </a></td>
				<td><a href="<?=config('follow_youtube')?>" target="_blank"><i class="fa fa-youtube"></i> </a></td>
				<td><a href="<?=config('follow_twitch')?>" target="_blank"><i class="fa fa-twitch"></i> </a></td>
			</tr>
		</table>

	</div>
</div>
