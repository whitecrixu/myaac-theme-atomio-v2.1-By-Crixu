# Modern Layout - OTS Template

# Preview
![atomio layout preview](https://github.com/idontreallywolf/ots_layouts/blob/atomio_layout/img/prev1.png)
![atomio layout preview](https://github.com/idontreallywolf/ots_layouts/blob/atomio_layout/img/prev2.png)
